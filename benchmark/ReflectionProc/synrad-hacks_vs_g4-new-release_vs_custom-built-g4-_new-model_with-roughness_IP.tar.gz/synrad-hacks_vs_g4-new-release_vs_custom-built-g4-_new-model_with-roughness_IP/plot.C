vector<Double_t> Pos_X_cm;
vector<Double_t> Pos_Y_cm;
vector<Double_t> Pos_Z_cm;
vector<Double_t> Pos_u;
vector<Double_t> Pos_v;
vector<Double_t> Dir_X;
vector<Double_t> Dir_Y;
vector<Double_t> Dir_Z;
vector<Double_t> Dir_theta_rad;
vector<Double_t> Dir_phi_rad; 
vector<Double_t> LowFluxRatio;
vector<Double_t> Energy_eV;
vector<Double_t> Flux_phs;
vector<Double_t> Power_W;

void readCSVfile(TString fName);
void readSynRadData(TString inputFileName, TH1D* h1_ene, TH1D* h1_dirx, TH1D* h1_diry, TH1D* h1_dirz, TH1D* h1_posx, TH1D* h1_posy, TH1D* h1_posz, TH2D* h1_ene_dirx, TH2D* h1_ene_diry, TH2D* h1_ene_dirz);
void getSynRadData(TString outputFileName = "synrad_data.root");

const Double_t beamCurrent_A = 0.227;
const Double_t nElectrons_g4 = 1000*1e5; // 1000 files x 1e5 e-/file

void plot()
{
	//-------------------------------------------------------------------------------------//
	//-- read the csv file

//	getSynRadData("synrad_data.root"); 
//	return;

	//-------------------------------------------------------------------------------------//
	//-- plot Synrad+ and Geant4 data

	gStyle->SetOptStat(0);

	const Double_t minE_eV =  0.000, maxE_eV = 20e03;
	const Double_t minDirx = -0.050, maxDirx = 0.050;
	const Double_t minDiry = -0.005, maxDiry = 0.005;
	const Double_t minDirz =  0.900, maxDirz = 1.010;
	const Double_t minX_cm = -4.00, maxX_cm = 4.00;
	const Double_t minY_cm = -4.00, maxY_cm = 4.00;
	const Double_t minZ_cm = -80.00, maxZ_cm = 80.00;

	const Int_t nfiles = 2;
	TString fName[nfiles] = {	"synrad_data.root",	// Synrad+ data (new model)
					"output_g4ana_3_all_hist.root"};	// Geant4 data (new model)
	Int_t lineWidth[nfiles] = {6,3};
	Int_t lineColor[nfiles] = {6/*magenta*/,1/*black*/};
	Int_t fillStyle[nfiles] = {1,0};
	Double_t fillAlpha[nfiles] = {0.3,1};
	TString legend[nfiles] = {	"Synrad+ (New model, diff.)",
					"Geant4  (New model, diff.)"};

	TFile *file[nfiles];
	TH1D* h1_ene[nfiles];
	TH1D* h1_dirx[nfiles];
	TH1D* h1_diry[nfiles];
	TH1D* h1_dirz[nfiles];
	TH1D* h1_posx[nfiles];
	TH1D* h1_posy[nfiles];
	TH1D* h1_posz[nfiles];
	TH2D* h1_ene_dirx[nfiles];
	TH2D* h1_ene_diry[nfiles];
	TH2D* h1_ene_dirz[nfiles];

	//-- get data
	for(Int_t i = 0; i < nfiles; i++)
	{
		file[i] = TFile::Open(fName[i].Data());

		// get
		h1_ene[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_ene_sr" : "h1_ene_g4"); h1_ene[i]->SetName(Form("h1_ene_%d",i));
		h1_dirx[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_dirx_sr" : "h1_dirx_g4"); h1_dirx[i]->SetName(Form("h1_dirx_%d",i));
		h1_diry[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_diry_sr" : "h1_diry_g4"); h1_diry[i]->SetName(Form("h1_diry_%d",i));
		h1_dirz[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_dirz_sr" : "h1_dirz_g4"); h1_dirz[i]->SetName(Form("h1_dirz_%d",i));
		h1_posx[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_posx_sr" : "h1_posx_g4"); h1_posx[i]->SetName(Form("h1_posx_%d",i));
		h1_posy[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_posy_sr" : "h1_posy_g4"); h1_posy[i]->SetName(Form("h1_posy_%d",i));
		h1_posz[i] = (TH1D*)file[i]->Get((i == 0 || i == 2) ? "h1_posz_sr" : "h1_posz_g4"); h1_posz[i]->SetName(Form("h1_posz_%d",i));
		h1_ene_dirx[i] = (TH2D*)file[i]->Get((i == 0 || i == 2) ? "h1_ene_dirx_sr" : "h1_ene_dirx_g4"); h1_ene_dirx[i]->SetName(Form("h1_ene_dirx_%d",i));
		h1_ene_diry[i] = (TH2D*)file[i]->Get((i == 0 || i == 2) ? "h1_ene_diry_sr" : "h1_ene_diry_g4"); h1_ene_diry[i]->SetName(Form("h1_ene_diry_%d",i));
		h1_ene_dirz[i] = (TH2D*)file[i]->Get((i == 0 || i == 2) ? "h1_ene_dirz_sr" : "h1_ene_dirz_g4"); h1_ene_dirz[i]->SetName(Form("h1_ene_dirz_%d",i));

		// scale Geant4 data
		if(i != 0 && i != 2)
		{
			h1_ene[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_dirx[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_diry[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_dirz[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_posx[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_posy[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_posz[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_ene_dirx[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_ene_diry[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
			h1_ene_dirz[i]->Scale(beamCurrent_A/(nElectrons_g4*TMath::Qe()));
		}
	}

	//-- plot data

	// spectrum
	TCanvas* c0 = new TCanvas("c0","c0",2000,2000);
	c0->cd();

	TLegend* leg0 = new TLegend(0.1,0.7,0.9,0.9);
	leg0->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_ene[i]->Rebin(100);
		cout<<h1_ene[i]->GetName()<<" bin width = "<<h1_ene[i]->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

		h1_ene[i]->SetLineWidth(lineWidth[i]);
		h1_ene[i]->SetLineColor(lineColor[i]);
		h1_ene[i]->SetFillStyle(fillStyle[i]);
		h1_ene[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_ene[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_ene[i]->GetXaxis()->SetRangeUser(minE_eV,maxE_eV);
		h1_ene[i]->GetXaxis()->SetNdivisions(5);
		h1_ene[i]->SetMinimum(1e11);
		h1_ene[i]->SetMaximum(1e19);

		if(i == 0) h1_ene[i]->Draw("HIST");
		else h1_ene[i]->Draw("SAME & HIST");

		leg0->AddEntry(h1_ene[i],legend[i].Data(),"f");
	}
	leg0->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	c0->SaveAs("c0.png");

	// coordinates and directions
	TCanvas* c1 = new TCanvas("c1","c1",4000,2000);
	c1->Divide(3,2);


	//-- dirx
	c1->cd(1);

	TLegend* leg1_dirx = new TLegend(0.1,0.7,0.9,0.9);
	leg1_dirx->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_dirx[i]->Rebin(100);
		cout<<h1_dirx[i]->GetName()<<" bin width = "<<h1_dirx[i]->GetXaxis()->GetBinWidth(1)<<" [a.u.]"<<endl;

		h1_dirx[i]->SetLineWidth(lineWidth[i]);
		h1_dirx[i]->SetLineColor(lineColor[i]);
		h1_dirx[i]->SetFillStyle(fillStyle[i]);
		h1_dirx[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_dirx[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_dirx[i]->GetXaxis()->SetRangeUser(minDirx,maxDirx);
		h1_dirx[i]->SetMinimum(1e11);
		h1_dirx[i]->SetMaximum(1e16);

		if(i == 0) h1_dirx[i]->Draw("HIST");
		else h1_dirx[i]->Draw("SAME & HIST");

		leg1_dirx->AddEntry(h1_dirx[i],legend[i].Data(),"f");
	}
	leg1_dirx->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- diry
	c1->cd(2);

	TLegend* leg1_diry = new TLegend(0.1,0.7,0.9,0.9);
	leg1_diry->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_diry[i]->Rebin(100);
		cout<<h1_diry[i]->GetName()<<" bin width = "<<h1_diry[i]->GetXaxis()->GetBinWidth(1)<<" [a.u.]"<<endl;

		h1_diry[i]->SetLineWidth(lineWidth[i]);
		h1_diry[i]->SetLineColor(lineColor[i]);
		h1_diry[i]->SetFillStyle(fillStyle[i]);
		h1_diry[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_diry[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_diry[i]->GetXaxis()->SetRangeUser(minDiry,maxDiry);
		h1_diry[i]->SetMinimum(1e11);
		h1_diry[i]->SetMaximum(1e16);

		if(i == 0) h1_diry[i]->Draw("HIST");
		else h1_diry[i]->Draw("SAME & HIST");

		leg1_diry->AddEntry(h1_diry[i],legend[i].Data(),"f");
	}
	leg1_diry->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- dirz
	c1->cd(3);

	TLegend* leg1_dirz = new TLegend(0.1,0.7,0.9,0.9);
	leg1_dirz->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_dirz[i]->Rebin(100);
		cout<<h1_dirz[i]->GetName()<<" bin width = "<<h1_dirz[i]->GetXaxis()->GetBinWidth(1)<<" [a.u.]"<<endl;

		h1_dirz[i]->SetLineWidth(lineWidth[i]);
		h1_dirz[i]->SetLineColor(lineColor[i]);
		h1_dirz[i]->SetFillStyle(fillStyle[i]);
		h1_dirz[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_dirz[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_dirz[i]->GetXaxis()->SetRangeUser(minDirz,maxDirz);
		h1_dirz[i]->SetMinimum(1e10);
		h1_dirz[i]->SetMaximum(1e19);

		if(i == 0) h1_dirz[i]->Draw("HIST");
		else h1_dirz[i]->Draw("SAME & HIST");

		leg1_dirz->AddEntry(h1_dirz[i],legend[i].Data(),"f");
	}
	leg1_dirz->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posx
	c1->cd(4);

	TLegend* leg1_posx = new TLegend(0.1,0.7,0.9,0.9);
	leg1_posx->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_posx[i]->Rebin(10);
		cout<<h1_posx[i]->GetName()<<" bin width = "<<h1_posx[i]->GetXaxis()->GetBinWidth(1)<<" [cm]"<<endl;

		h1_posx[i]->SetLineWidth(lineWidth[i]);
		h1_posx[i]->SetLineColor(lineColor[i]);
		h1_posx[i]->SetFillStyle(fillStyle[i]);
		h1_posx[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_posx[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_posx[i]->GetXaxis()->SetRangeUser(minX_cm,maxX_cm);
		h1_posx[i]->SetMinimum(1e12);
		h1_posx[i]->SetMaximum(1e18);

		if(i == 0) h1_posx[i]->Draw("HIST");
		else h1_posx[i]->Draw("SAME & HIST");

		leg1_posx->AddEntry(h1_posx[i],legend[i].Data(),"f");
	}
	leg1_posx->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posy
	c1->cd(5);

	TLegend* leg1_posy = new TLegend(0.1,0.7,0.9,0.9);
	leg1_posy->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_posy[i]->Rebin(100);
		cout<<h1_posy[i]->GetName()<<" bin width = "<<h1_posy[i]->GetXaxis()->GetBinWidth(1)<<" [cm]"<<endl;

		h1_posy[i]->SetLineWidth(lineWidth[i]);
		h1_posy[i]->SetLineColor(lineColor[i]);
		h1_posy[i]->SetFillStyle(fillStyle[i]);
		h1_posy[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_posy[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_posy[i]->GetXaxis()->SetRangeUser(minY_cm,maxY_cm);
		h1_posy[i]->SetMinimum(1e10);
		h1_posy[i]->SetMaximum(1e17);

		if(i == 0) h1_posy[i]->Draw("HIST");
		else h1_posy[i]->Draw("SAME & HIST");

		leg1_posy->AddEntry(h1_posy[i],legend[i].Data(),"f");
	}
	leg1_posy->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posz
	c1->cd(6);

	TLegend* leg1_posz = new TLegend(0.1,0.7,0.9,0.9);
	leg1_posz->SetNColumns(2);

	for(Int_t i = 0; i < nfiles; i++)
	{
		h1_posz[i]->Rebin(10);
		cout<<h1_posz[i]->GetName()<<" bin width = "<<h1_posz[i]->GetXaxis()->GetBinWidth(1)<<" [cm]"<<endl;

		h1_posz[i]->SetLineWidth(lineWidth[i]);
		h1_posz[i]->SetLineColor(lineColor[i]);
		h1_posz[i]->SetFillStyle(fillStyle[i]);
		h1_posz[i]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);

		h1_posz[i]->GetYaxis()->SetTitleOffset(1.15);
		h1_posz[i]->GetXaxis()->SetRangeUser(minZ_cm,maxZ_cm);
		h1_posz[i]->SetMinimum(1e11);
		h1_posz[i]->SetMaximum(1e17);

		if(i == 0) h1_posz[i]->Draw("HIST");
		else h1_posz[i]->Draw("SAME & HIST");

		leg1_posz->AddEntry(h1_posz[i],legend[i].Data(),"f");
	}
	leg1_posz->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	c1->SaveAs("c1.png");

	// spectrum vs angle
	TCanvas* c2 = new TCanvas("c2","c2",4000,2000);
	c2->Divide(2,2);

	TLegend* leg2 = new TLegend(0.1,0.7,0.9,0.9);
	leg2->SetNColumns(2);

	TH1D* projy_h1_ene_dirx[nfiles][100];
	const Double_t ddrix = 0.005;
	for(Int_t bini = 0; bini < 4; bini++)
	{
		Double_t dirx_min = -0.025 + bini*ddrix;
		Double_t dirx_max = -0.025 + (bini+1)*ddrix;

		c2->cd(bini+1);
		for(Int_t i = 0; i < nfiles; i++)
		{
			projy_h1_ene_dirx[i][bini] = (TH1D*)h1_ene_dirx[i]->ProjectionY(Form("projy_h1_ene_dirx_%d_%d",i,bini),h1_ene_dirx[i]->GetXaxis()->FindBin(dirx_min),h1_ene_dirx[i]->GetXaxis()->FindBin(dirx_max));

			projy_h1_ene_dirx[i][bini]->Rebin(10);
			projy_h1_ene_dirx[i][bini]->SetLineWidth(lineWidth[i]);
			projy_h1_ene_dirx[i][bini]->SetLineColor(lineColor[i]);
			projy_h1_ene_dirx[i][bini]->SetFillStyle(fillStyle[i]);
			projy_h1_ene_dirx[i][bini]->SetFillColorAlpha(lineColor[i],fillAlpha[i]);
		
			projy_h1_ene_dirx[i][bini]->GetYaxis()->SetTitleOffset(1.15);
			projy_h1_ene_dirx[i][bini]->GetXaxis()->SetRangeUser(minE_eV,maxE_eV);
			projy_h1_ene_dirx[i][bini]->GetXaxis()->SetNdivisions(5);
			projy_h1_ene_dirx[i][bini]->SetTitle(Form("Px_{#gamma}/E_{#gamma} = [%.1f,%.1f] mrad",dirx_min*1e3,dirx_max*1e3));
			projy_h1_ene_dirx[i][bini]->SetMinimum(1e10);
			projy_h1_ene_dirx[i][bini]->SetMaximum(1e16);

			if(i == 0) projy_h1_ene_dirx[i][bini]->Draw("HIST");
			else projy_h1_ene_dirx[i][bini]->Draw("HIST & SAME");

			if(bini == 0) leg2->AddEntry(projy_h1_ene_dirx[i][bini],legend[i].Data(),"f");
		}
		leg2->Draw();
		
		gPad->SetGrid();
		gPad->SetLogy();

	}
	c2->SaveAs("c2.png");

	return;
}

void getSynRadData(TString outputFileName = "synrad_data.root")
{
	TFile* file = new TFile(outputFileName.Data(),"recreate");
	file->cd();

	TH1D* h1_ene_sr = new TH1D("h1_ene_sr","SR photon spectrum;E_{#gamma} [eV];Flux [ph/s]",1e6,0,1e6); 
	TH1D* h1_dirx_sr = new TH1D("h1_dirx_sr","SR photon momentum X; Px_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_diry_sr = new TH1D("h1_diry_sr","SR photon momentum Y; Py_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_dirz_sr = new TH1D("h1_dirz_sr","SR photon momentum Z; Pz_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_posx_sr = new TH1D("h1_posx_sr","SR photon position X; X_{#gamma} [cm];Flux [ph/s]",10000,-10,0);  
	TH1D* h1_posy_sr = new TH1D("h1_posy_sr","SR photon position Y; Y_{#gamma} [cm];Flux [ph/s]",2000,-1,1); 
	TH1D* h1_posz_sr = new TH1D("h1_posz_sr","SR photon position Z; Z_{#gamma} [cm];Flux [ph/s]",11000,-3400,-2300);
	TH2D* h1_ene_dirx_sr = new TH2D("h1_ene_dirx_sr","SR photon energy vs momDir X;Px_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);
	TH2D* h1_ene_diry_sr = new TH2D("h1_ene_diry_sr","SR photon energy vs momDir Y;Py_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);
	TH2D* h1_ene_dirz_sr = new TH2D("h1_ene_dirz_sr","SR photon energy vs momDir Z;Pz_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);

	readSynRadData("28754.csv",h1_ene_sr,h1_dirx_sr,h1_diry_sr,h1_dirz_sr,h1_posx_sr,h1_posy_sr,h1_posz_sr,h1_ene_dirx_sr,h1_ene_diry_sr,h1_ene_dirz_sr);
	readSynRadData("28755.csv",h1_ene_sr,h1_dirx_sr,h1_diry_sr,h1_dirz_sr,h1_posx_sr,h1_posy_sr,h1_posz_sr,h1_ene_dirx_sr,h1_ene_diry_sr,h1_ene_dirz_sr);

	h1_ene_sr->Write();
	h1_dirx_sr->Write();
	h1_diry_sr->Write();
	h1_dirz_sr->Write();
	h1_posx_sr->Write();
	h1_posy_sr->Write();
	h1_posz_sr->Write();
	h1_ene_dirx_sr->Write();
	h1_ene_diry_sr->Write();
	h1_ene_dirz_sr->Write();
	file->Close();

	cout<<"Output Synrad+ file name = "<<file->GetName()<<endl;

	return;
}

void readSynRadData(TString inputFileName, TH1D* h1_ene, TH1D* h1_dirx, TH1D* h1_diry, TH1D* h1_dirz, TH1D* h1_posx, TH1D* h1_posy, TH1D* h1_posz, TH2D* h1_ene_dirx, TH2D* h1_ene_diry, TH2D* h1_ene_dirz)
{
	// clean data vectors
	Pos_X_cm.clear();
	Pos_Y_cm.clear();
	Pos_Z_cm.clear();
	Pos_u.clear();
	Pos_v.clear();
	Dir_X.clear();
	Dir_Y.clear();
	Dir_Z.clear();
	Dir_theta_rad.clear();
	Dir_phi_rad.clear(); 
	LowFluxRatio.clear();
	Energy_eV.clear();
	Flux_phs.clear();
	Power_W.clear();

	// read a CSV file
	readCSVfile(inputFileName);

	for(Int_t i = 0; i < Energy_eV.size(); i++)
	{
		if(Energy_eV.at(i) > 30.0)
		{
			h1_ene->Fill(Energy_eV.at(i),Flux_phs.at(i));
			h1_posx->Fill(Pos_X_cm.at(i),Flux_phs.at(i));
			h1_posy->Fill(Pos_Y_cm.at(i),Flux_phs.at(i));
			h1_posz->Fill(Pos_Z_cm.at(i),Flux_phs.at(i));
			h1_dirx->Fill(Dir_X.at(i),Flux_phs.at(i));
			h1_diry->Fill(Dir_Y.at(i),Flux_phs.at(i));
			h1_dirz->Fill(Dir_Z.at(i),Flux_phs.at(i));
			h1_ene_dirx->Fill(Dir_X.at(i),Energy_eV.at(i),Flux_phs.at(i));
			h1_ene_diry->Fill(Dir_Y.at(i),Energy_eV.at(i),Flux_phs.at(i));
			h1_ene_dirz->Fill(Dir_Z.at(i),Energy_eV.at(i),Flux_phs.at(i));
		}
	}

	return;
}

void readCSVfile(TString fName)
{
	cout<<"Input file name: "<<fName<<endl;

	// Create an input filestream
    	ifstream myFile(fName.Data());

    	// Helper vars
    	string line, colname;
    	Double_t val;

    	// Read data, line by line
	getline(myFile, line); // skepp the first title line

    	while(getline(myFile, line))
    	{
        	// Create a stringstream of the current line
        	stringstream ss(line);
        
        	// Keep track of the current column index
        	Int_t colIdx = 0;
        
        	// Extract each value
        	while(ss >> val)
		{
            		// Add the current integer to the 'colIdx' column's values vector
			switch(colIdx)
			{
				case 0:
					Pos_X_cm.push_back(val);
					break;
				case 1:
					Pos_Y_cm.push_back(val);
					break;
				case 2:
					Pos_Z_cm.push_back(val);
					break;
				case 3:
					Pos_u.push_back(val);
					break;
				case 4:
					Pos_v.push_back(val);
					break;
				case 5:
					Dir_X.push_back(val);
					break;
				case 6:
					Dir_Y.push_back(val);
					break;
				case 7:
					Dir_Z.push_back(val);
					break;
				case 8:
					Dir_theta_rad.push_back(val);
					break;
				case 9:
					Dir_phi_rad.push_back(val);
					break;
				case 10:
					LowFluxRatio.push_back(val);
					break;
				case 11:
					Energy_eV.push_back(val);
					break;
				case 12:
					Flux_phs.push_back(val);
					break;
				case 13:
					Power_W.push_back(val);
					break;
			}
            
            		// If the next token is a comma, ignore it and move on
            		if(ss.peek() == ',') ss.ignore();
            
            		// Increment the column index
            		colIdx++;
        	}
    	}

    	// Close file
    	myFile.close();

	return;
}
