vector<Double_t> Pos_X_cm;
vector<Double_t> Pos_Y_cm;
vector<Double_t> Pos_Z_cm;
vector<Double_t> Pos_u;
vector<Double_t> Pos_v;
vector<Double_t> Dir_X;
vector<Double_t> Dir_Y;
vector<Double_t> Dir_Z;
vector<Double_t> Dir_theta_rad;
vector<Double_t> Dir_phi_rad; 
vector<Double_t> LowFluxRatio;
vector<Double_t> Energy_eV;
vector<Double_t> Flux_phs;
vector<Double_t> Power_W;

void readCSVfile(TString fName);
void readSynRadData(TString inputFileName, TH1D* h1_ene, TH1D* h1_dirx, TH1D* h1_diry, TH1D* h1_dirz, TH1D* h1_posx, TH1D* h1_posy, TH1D* h1_posz, TH2D* h1_ene_dirx, TH2D* h1_ene_diry, TH2D* h1_ene_dirz);
void getSynRadData(TString outputFileName = "synrad_data.root");

const Double_t beamCurrent_A = 0.227;
const Double_t nElectrons_g4 = 10*1e5; // 10 files x 1e5 e-/file
const Double_t nElectrons_g4_twoModels = 1000*1e5; // 1000 files x 1e5 e-/file

void plot()
{
	const Double_t minE_eV =  0.00, maxE_eV =    20e3;
	const Double_t minDirx = -0.026, maxDirx =  -0.005;
	const Double_t minDiry = -0.003, maxDiry =   0.003;
	const Double_t minDirz =  0.95, maxDirz =  1.01;
	const Double_t minX_eV = -5.02, maxX_eV = -4.90;
	const Double_t minY_eV = -1.00, maxY_eV =  1.00;
	const Double_t minZ_eV = -3400, maxZ_eV = -2300;

	gStyle->SetOptStat(0);

	//-- read the csv file
//	getSynRadData("synrad_data_r0.root"); 
//	return;

	/* _r0 means surface roughness = 0 */

	// get synrad+ data
	TFile *file_sr = TFile::Open("synrad_data_r0.root");
	TH1D* h1_ene_sr = (TH1D*)file_sr->Get("h1_ene_sr");
	TH1D* h1_dirx_sr = (TH1D*)file_sr->Get("h1_dirx_sr");
	TH1D* h1_diry_sr = (TH1D*)file_sr->Get("h1_diry_sr");
	TH1D* h1_dirz_sr = (TH1D*)file_sr->Get("h1_dirz_sr");
	TH1D* h1_posx_sr = (TH1D*)file_sr->Get("h1_posx_sr");
	TH1D* h1_posy_sr = (TH1D*)file_sr->Get("h1_posy_sr");
	TH1D* h1_posz_sr = (TH1D*)file_sr->Get("h1_posz_sr");
	TH2D* h1_ene_dirx_sr = (TH2D*)file_sr->Get("h1_ene_dirx_sr");
	TH2D* h1_ene_diry_sr = (TH2D*)file_sr->Get("h1_ene_diry_sr");
	TH2D* h1_ene_dirz_sr = (TH2D*)file_sr->Get("h1_ene_dirz_sr");

	// get geant4 data (GammaReflection based on a Synrad+ model)
	TFile *file_g4_1 = TFile::Open("output_g4ana_core_solenoid_synradmodel_r0_all.root");
	TH1D* h1_ene_g4_1 = (TH1D*)file_g4_1->Get("h1_ene_g4"); h1_ene_g4_1->SetName("h1_ene_g4_1");
	TH1D* h1_dirx_g4_1 = (TH1D*)file_g4_1->Get("h1_dirx_g4"); h1_dirx_g4_1->SetName("h1_dirx_g4_1");
	TH1D* h1_diry_g4_1 = (TH1D*)file_g4_1->Get("h1_diry_g4"); h1_diry_g4_1->SetName("h1_diry_g4_1");
	TH1D* h1_dirz_g4_1 = (TH1D*)file_g4_1->Get("h1_dirz_g4"); h1_dirz_g4_1->SetName("h1_dirz_g4_1");
	TH1D* h1_posx_g4_1 = (TH1D*)file_g4_1->Get("h1_posx_g4"); h1_posx_g4_1->SetName("h1_posx_g4_1");
	TH1D* h1_posy_g4_1 = (TH1D*)file_g4_1->Get("h1_posy_g4"); h1_posy_g4_1->SetName("h1_posy_g4_1");
	TH1D* h1_posz_g4_1 = (TH1D*)file_g4_1->Get("h1_posz_g4"); h1_posz_g4_1->SetName("h1_posz_g4_1");
	TH2D* h1_ene_dirx_g4_1 = (TH2D*)file_g4_1->Get("h1_ene_dirx_g4"); h1_ene_dirx_g4_1->SetName("h1_ene_dirx_g4_1");
	TH2D* h1_ene_diry_g4_1 = (TH2D*)file_g4_1->Get("h1_ene_diry_g4"); h1_ene_diry_g4_1->SetName("h1_ene_diry_g4_1");
	TH2D* h1_ene_dirz_g4_1 = (TH2D*)file_g4_1->Get("h1_ene_dirz_g4"); h1_ene_dirz_g4_1->SetName("h1_ene_dirz_g4_1");

	// get geant4 data (XrayReflection based on a new Geant4 model)
	TFile *file_g4_2 = TFile::Open("output_g4ana_core_solenoid_geantmodel_r0_all.root");
	TH1D* h1_ene_g4_2 = (TH1D*)file_g4_2->Get("h1_ene_g4"); h1_ene_g4_2->SetName("h1_ene_g4_2");
	TH1D* h1_dirx_g4_2 = (TH1D*)file_g4_2->Get("h1_dirx_g4"); h1_dirx_g4_2->SetName("h1_dirx_g4_2");
	TH1D* h1_diry_g4_2 = (TH1D*)file_g4_2->Get("h1_diry_g4"); h1_diry_g4_2->SetName("h1_diry_g4_2");
	TH1D* h1_dirz_g4_2 = (TH1D*)file_g4_2->Get("h1_dirz_g4"); h1_dirz_g4_2->SetName("h1_dirz_g4_2");
	TH1D* h1_posx_g4_2 = (TH1D*)file_g4_2->Get("h1_posx_g4"); h1_posx_g4_2->SetName("h1_posx_g4_2");
	TH1D* h1_posy_g4_2 = (TH1D*)file_g4_2->Get("h1_posy_g4"); h1_posy_g4_2->SetName("h1_posy_g4_2");
	TH1D* h1_posz_g4_2 = (TH1D*)file_g4_2->Get("h1_posz_g4"); h1_posz_g4_2->SetName("h1_posz_g4_2");
	TH2D* h1_ene_dirx_g4_2 = (TH2D*)file_g4_2->Get("h1_ene_dirx_g4"); h1_ene_dirx_g4_2->SetName("h1_ene_dirx_g4_2");
	TH2D* h1_ene_diry_g4_2 = (TH2D*)file_g4_2->Get("h1_ene_diry_g4"); h1_ene_diry_g4_2->SetName("h1_ene_diry_g4_2");
	TH2D* h1_ene_dirz_g4_2 = (TH2D*)file_g4_2->Get("h1_ene_dirz_g4"); h1_ene_dirz_g4_2->SetName("h1_ene_dirz_g4_2");

	// scale geant4 -> synrad
	h1_ene_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_dirx_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_diry_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_dirz_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posx_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posy_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posz_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_dirx_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_diry_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_dirz_g4_1->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));

	h1_ene_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_dirx_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_diry_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_dirz_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posx_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posy_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_posz_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_dirx_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_diry_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));
	h1_ene_dirz_g4_2->Scale(beamCurrent_A/(nElectrons_g4_twoModels*TMath::Qe()));

	//=========================================================================================//
	// plot data
	TCanvas* c0 = new TCanvas("c0","c0",900,900);
	c0->cd();

	h1_ene_sr->Rebin(100);
	h1_ene_g4_1->Rebin(100);
	h1_ene_g4_2->Rebin(100);
	cout<<"h1_ene_sr bin width = "<<h1_ene_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_ene_g4_1 bin width = "<<h1_ene_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_ene_g4_2 bin width = "<<h1_ene_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_ene_sr->SetLineWidth(3);
	h1_ene_g4_1->SetLineWidth(2);
	h1_ene_g4_2->SetLineWidth(2);
	h1_ene_sr->SetLineColor(kMagenta);
	h1_ene_sr->SetFillColor(kMagenta);
	h1_ene_sr->SetFillStyle(3354);
	h1_ene_g4_1->SetLineColor(kGreen+1);
	h1_ene_g4_2->SetLineColor(kBlack);
	h1_ene_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_ene_sr->GetXaxis()->SetRangeUser(minE_eV,maxE_eV);
	h1_ene_sr->SetMinimum(1e15);
	h1_ene_sr->SetMaximum(1e19);

	h1_ene_sr->Draw("HIST");
	h1_ene_g4_1->Draw("SAME & HIST");
	h1_ene_g4_2->Draw("SAME & HIST");

	TLegend* leg0 = new TLegend(0.6,0.7,0.9,0.9);
	leg0->AddEntry(h1_ene_sr,"Synrad+","f");
	leg0->AddEntry(h1_ene_g4_1,"Geant4 (Gamma)","f");
	leg0->AddEntry(h1_ene_g4_2,"Geant4 (Xray)","f");
	leg0->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	c0->SaveAs("c0.png");

	//=========================================================================================//
	TCanvas* c1 = new TCanvas("c1","c1",1800,900);
	c1->Divide(3,2);

	//-- dirx
	c1->cd(1);

	h1_dirx_sr->Rebin(10);
	h1_dirx_g4_1->Rebin(10);
	h1_dirx_g4_2->Rebin(10);
	cout<<"h1_dirx_sr bin width = "<<h1_dirx_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_dirx_g4_1 bin width = "<<h1_dirx_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_dirx_g4_2 bin width = "<<h1_dirx_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_dirx_sr->SetLineWidth(3);
	h1_dirx_g4_1->SetLineWidth(2);
	h1_dirx_g4_2->SetLineWidth(2);
	h1_dirx_sr->SetLineColor(kMagenta);
	h1_dirx_sr->SetFillColor(kMagenta);
	h1_dirx_sr->SetFillStyle(3354);
	h1_dirx_g4_1->SetLineColor(kGreen+1);
	h1_dirx_g4_2->SetLineColor(kBlack);
	h1_dirx_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_dirx_sr->GetXaxis()->SetRangeUser(minDirx,maxDirx);
	h1_dirx_sr->SetMinimum(1e15);
	h1_dirx_sr->SetMaximum(1e16);

	h1_dirx_sr->Draw("HIST");
	h1_dirx_g4_1->Draw("SAME & HIST");
	h1_dirx_g4_2->Draw("SAME & HIST");

	TLegend* leg_dirx = new TLegend(0.2,0.7,0.5,0.9);
	leg_dirx->AddEntry(h1_dirx_sr,"Synrad+","f");
	leg_dirx->AddEntry(h1_dirx_g4_1,"Geant4 (Gamma)","f");
	leg_dirx->AddEntry(h1_dirx_g4_2,"Geant4 (Xray)","f");
	leg_dirx->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- diry
	c1->cd(2);

	h1_diry_sr->Rebin(10);
	h1_diry_g4_1->Rebin(10);
	h1_diry_g4_2->Rebin(10);
	cout<<"h1_diry_sr bin width = "<<h1_diry_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_diry_g4_1 bin width = "<<h1_diry_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_diry_g4_2 bin width = "<<h1_diry_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_diry_sr->SetLineWidth(3);
	h1_diry_g4_1->SetLineWidth(2);
	h1_diry_g4_2->SetLineWidth(2);
	h1_diry_sr->SetLineColor(kMagenta);
	h1_diry_sr->SetFillColor(kMagenta);
	h1_diry_sr->SetFillStyle(3354);
	h1_diry_g4_1->SetLineColor(kGreen+1);
	h1_diry_g4_2->SetLineColor(kBlack);
	h1_diry_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_diry_sr->GetXaxis()->SetRangeUser(minDiry,maxDiry);
	h1_diry_sr->SetMinimum(1e11);
	h1_diry_sr->SetMaximum(1e19);

	h1_diry_sr->Draw("HIST");
	h1_diry_g4_1->Draw("SAME & HIST");
	h1_diry_g4_2->Draw("SAME & HIST");

	TLegend* leg_diry = new TLegend(0.6,0.7,0.9,0.9);
	leg_diry->AddEntry(h1_diry_sr,"Synrad+","f");
	leg_diry->AddEntry(h1_diry_g4_1,"Geant4 (Gamma)","f");
	leg_diry->AddEntry(h1_diry_g4_2,"Geant4 (Xray)","f");
	leg_diry->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- dirz
	c1->cd(3);

	h1_dirz_sr->Rebin(100);
	h1_dirz_g4_1->Rebin(100);
	h1_dirz_g4_2->Rebin(100);
	cout<<"h1_dirz_sr bin width = "<<h1_dirz_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_dirz_g4_1 bin width = "<<h1_dirz_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_dirz_g4_2 bin width = "<<h1_dirz_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_dirz_sr->SetLineWidth(3);
	h1_dirz_g4_1->SetLineWidth(2);
	h1_dirz_g4_2->SetLineWidth(2);
	h1_dirz_sr->SetLineColor(kMagenta);
	h1_dirz_sr->SetFillColor(kMagenta);
	h1_dirz_sr->SetFillStyle(3354);
	h1_dirz_g4_1->SetLineColor(kGreen+1);
	h1_dirz_g4_2->SetLineColor(kBlack);
	h1_dirz_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_dirz_sr->GetXaxis()->SetRangeUser(minDirz,maxDirz);
	h1_dirz_sr->SetMinimum(1e11);
	h1_dirz_sr->SetMaximum(1e22);

	h1_dirz_sr->Draw("HIST");
	h1_dirz_g4_1->Draw("SAME & HIST");
	h1_dirz_g4_2->Draw("SAME & HIST");

	TLegend* leg_dirz = new TLegend(0.6,0.7,0.9,0.9);
	leg_dirz->AddEntry(h1_dirz_sr,"Synrad+","f");
	leg_dirz->AddEntry(h1_dirz_g4_1,"Geant4 (Gamma)","f");
	leg_dirz->AddEntry(h1_dirz_g4_2,"Geant4 (Xray)","f");
	leg_dirz->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posx
	c1->cd(4);

	h1_posx_sr->Rebin(1);
	h1_posx_g4_1->Rebin(1);
	h1_posx_g4_2->Rebin(1);
	cout<<"h1_posx_sr bin width = "<<h1_posx_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posx_g4_1 bin width = "<<h1_posx_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posx_g4_2 bin width = "<<h1_posx_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_posx_sr->SetLineWidth(3);
	h1_posx_g4_1->SetLineWidth(2);
	h1_posx_g4_2->SetLineWidth(2);
	h1_posx_sr->SetLineColor(kMagenta);
	h1_posx_sr->SetFillColor(kMagenta);
	h1_posx_sr->SetFillStyle(3354);
	h1_posx_g4_1->SetLineColor(kGreen+1);
	h1_posx_g4_2->SetLineColor(kBlack);
	h1_posx_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_posx_sr->GetXaxis()->SetRangeUser(minX_eV,maxX_eV);
	h1_posx_sr->SetMinimum(1e11);
	h1_posx_sr->SetMaximum(1e20);

	h1_posx_sr->Draw("HIST");
	h1_posx_g4_1->Draw("SAME & HIST");
	h1_posx_g4_2->Draw("SAME & HIST");

	TLegend* leg_posx = new TLegend(0.6,0.7,0.9,0.9);
	leg_posx->AddEntry(h1_posx_sr,"Synrad+","f");
	leg_posx->AddEntry(h1_posx_g4_1,"Geant4 (Gamma)","f");
	leg_posx->AddEntry(h1_posx_g4_2,"Geant4 (Xray)","f");
	leg_posx->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posy
	c1->cd(5);

	h1_posy_sr->Rebin(10);
	h1_posy_g4_1->Rebin(10);
	h1_posy_g4_2->Rebin(10);
	cout<<"h1_posy_sr bin width = "<<h1_posy_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posy_g4_1 bin width = "<<h1_posy_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posy_g4_2 bin width = "<<h1_posy_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_posy_sr->SetLineWidth(3);
	h1_posy_g4_1->SetLineWidth(2);
	h1_posy_g4_2->SetLineWidth(2);
	h1_posy_sr->SetLineColor(kMagenta);
	h1_posy_sr->SetFillColor(kMagenta);
	h1_posy_sr->SetFillStyle(3354);
	h1_posy_g4_1->SetLineColor(kGreen+1);
	h1_posy_g4_2->SetLineColor(kBlack);
	h1_posy_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_posy_sr->GetXaxis()->SetRangeUser(minY_eV,maxY_eV);
	h1_posy_sr->SetMinimum(1e11);
	h1_posy_sr->SetMaximum(1e20);

	h1_posy_sr->Draw("HIST");
	h1_posy_g4_1->Draw("SAME & HIST");
	h1_posy_g4_2->Draw("SAME & HIST");

	TLegend* leg_posy = new TLegend(0.6,0.7,0.9,0.9);
	leg_posy->AddEntry(h1_posy_sr,"Synrad+","f");
	leg_posy->AddEntry(h1_posy_g4_1,"Geant4 (Gamma)","f");
	leg_posy->AddEntry(h1_posy_g4_2,"Geant4 (Xray)","f");
	leg_posy->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	//-- posz
	c1->cd(6);

	h1_posz_sr->Rebin(10);
	h1_posz_g4_1->Rebin(10);
	h1_posz_g4_2->Rebin(10);
	cout<<"h1_posz_sr bin width = "<<h1_posz_sr->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posz_g4_1 bin width = "<<h1_posz_g4_1->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;
	cout<<"h1_posz_g4_2 bin width = "<<h1_posz_g4_2->GetXaxis()->GetBinWidth(1)<<" [eV]"<<endl;

	h1_posz_sr->SetLineWidth(3);
	h1_posz_g4_1->SetLineWidth(2);
	h1_posz_g4_2->SetLineWidth(2);
	h1_posz_sr->SetLineColor(kMagenta);
	h1_posz_sr->SetFillColor(kMagenta);
	h1_posz_sr->SetFillStyle(3354);
	h1_posz_g4_1->SetLineColor(kGreen+1);
	h1_posz_g4_2->SetLineColor(kBlack);
	h1_posz_g4_1->SetFillColorAlpha(kGreen+1,0.3);

	h1_posz_sr->GetXaxis()->SetRangeUser(minZ_eV,maxZ_eV);
	h1_posz_sr->SetMinimum(1e14);
	h1_posz_sr->SetMaximum(1e17);

	h1_posz_sr->Draw("HIST");
	h1_posz_g4_1->Draw("SAME & HIST");
	h1_posz_g4_2->Draw("SAME & HIST");

	TLegend* leg_posz = new TLegend(0.6,0.7,0.9,0.9);
	leg_posz->AddEntry(h1_posz_sr,"Synrad+","f");
	leg_posz->AddEntry(h1_posz_g4_1,"Geant4 (Gamma)","f");
	leg_posz->AddEntry(h1_posz_g4_2,"Geant4 (Xray)","f");
	leg_posz->Draw();

	gPad->SetGrid();
	gPad->SetLogy();

	c1->SaveAs("c1.png");
	//=========================================================================================//
	TCanvas* c2 = new TCanvas("c2","c2",1800,900);
	c2->Divide(2,2);

	TH1D* projy_h1_ene_dirx_sr[100];
	TH1D* projy_h1_ene_dirx_g4_1[100];
	TH1D* projy_h1_ene_dirx_g4_2[100];
	const Double_t ddrix = 0.005;
	for(Int_t bini = 0; bini < 4; bini++)
	{
		Double_t dirx_min = -0.025 + bini*ddrix;
		Double_t dirx_max = -0.025 + (bini+1)*ddrix;
		projy_h1_ene_dirx_sr[bini] = (TH1D*)h1_ene_dirx_sr->ProjectionY(Form("projy_h1_ene_dirx_sr_%d",bini),h1_ene_dirx_sr->GetXaxis()->FindBin(dirx_min),h1_ene_dirx_sr->GetXaxis()->FindBin(dirx_max));
		projy_h1_ene_dirx_g4_1[bini] = (TH1D*)h1_ene_dirx_g4_1->ProjectionY(Form("projy_h1_ene_dirx_g4_1_%d",bini),h1_ene_dirx_g4_1->GetXaxis()->FindBin(dirx_min),h1_ene_dirx_g4_1->GetXaxis()->FindBin(dirx_max));
		projy_h1_ene_dirx_g4_2[bini] = (TH1D*)h1_ene_dirx_g4_2->ProjectionY(Form("projy_h1_ene_dirx_g4_2_%d",bini),h1_ene_dirx_g4_2->GetXaxis()->FindBin(dirx_min),h1_ene_dirx_g4_2->GetXaxis()->FindBin(dirx_max));

		projy_h1_ene_dirx_sr[bini]->Rebin(1);
		projy_h1_ene_dirx_g4_1[bini]->Rebin(1);
		projy_h1_ene_dirx_g4_2[bini]->Rebin(1);

		projy_h1_ene_dirx_sr[bini]->SetLineWidth(3);
		projy_h1_ene_dirx_g4_1[bini]->SetLineWidth(2);
		projy_h1_ene_dirx_g4_2[bini]->SetLineWidth(2);
		projy_h1_ene_dirx_sr[bini]->SetLineColor(kMagenta);
		projy_h1_ene_dirx_sr[bini]->SetFillColor(kMagenta);
		projy_h1_ene_dirx_sr[bini]->SetFillStyle(3354);
		projy_h1_ene_dirx_g4_1[bini]->SetLineColor(kGreen+1);
		projy_h1_ene_dirx_g4_2[bini]->SetLineColor(kBlack);
		projy_h1_ene_dirx_g4_1[bini]->SetFillColorAlpha(kGreen+1,0.3);
		
		projy_h1_ene_dirx_sr[bini]->SetTitle(Form("Px_{#gamma}/E_{#gamma} = [%.1f,%.1f] mrad",dirx_min*1e3,dirx_max*1e3));
		projy_h1_ene_dirx_sr[bini]->SetMinimum(1e13);
		projy_h1_ene_dirx_sr[bini]->SetMaximum(1e17);

		c2->cd(bini+1);
		projy_h1_ene_dirx_sr[bini]->Draw("HIST");
		projy_h1_ene_dirx_g4_1[bini]->Draw("HIST & SAME");
		projy_h1_ene_dirx_g4_2[bini]->Draw("HIST & SAME");

		gPad->SetGrid();
		gPad->SetLogy();

		TLegend* leg2 = new TLegend(0.6,0.7,0.9,0.9);
		leg2->AddEntry(projy_h1_ene_dirx_sr[bini],"Synrad+","f");
		leg2->AddEntry(projy_h1_ene_dirx_g4_1[bini],"Geant4 (Gamma)","f");
		leg2->AddEntry(projy_h1_ene_dirx_g4_2[bini],"Geant4 (Xray)","f");
		leg2->Draw();
	}
	c2->SaveAs("c2.png");
	//=========================================================================================//


	return;
}

void getSynRadData(TString outputFileName = "synrad_data.root")
{
	TFile* file = new TFile(outputFileName.Data(),"recreate");
	file->cd();

	TH1D* h1_ene_sr = new TH1D("h1_ene_sr","SR photon spectrum;E_{#gamma} [eV];Flux [ph/s]",1e6,0,1e6); 
	TH1D* h1_dirx_sr = new TH1D("h1_dirx_sr","SR photon momentum X; Px_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_diry_sr = new TH1D("h1_diry_sr","SR photon momentum Y; Py_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_dirz_sr = new TH1D("h1_dirz_sr","SR photon momentum Z; Pz_{#gamma}/E_{#gamma};Flux [ph/s]",4e6,-2,2); 
	TH1D* h1_posx_sr = new TH1D("h1_posx_sr","SR photon position X; X_{#gamma} [eV];Flux [ph/s]",10000,-10,0);  
	TH1D* h1_posy_sr = new TH1D("h1_posy_sr","SR photon position Y; Y_{#gamma} [eV];Flux [ph/s]",2000,-1,1); 
	TH1D* h1_posz_sr = new TH1D("h1_posz_sr","SR photon position Z; Z_{#gamma} [eV];Flux [ph/s]",11000,-3400,-2300);
	TH2D* h1_ene_dirx_sr = new TH2D("h1_ene_dirx_sr","SR photon energy vs momDir X;Px_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);
	TH2D* h1_ene_diry_sr = new TH2D("h1_ene_diry_sr","SR photon energy vs momDir Y;Py_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);
	TH2D* h1_ene_dirz_sr = new TH2D("h1_ene_dirz_sr","SR photon energy vs momDir Z;Pz_{#gamma}/E_{#gamma};E_{#gamma} [eV];Flux [ph/s]",4e3,-2,2,4e3,0,40e3);

	readSynRadData("28754_r0.csv",h1_ene_sr,h1_dirx_sr,h1_diry_sr,h1_dirz_sr,h1_posx_sr,h1_posy_sr,h1_posz_sr,h1_ene_dirx_sr,h1_ene_diry_sr,h1_ene_dirz_sr);
	readSynRadData("28755_r0.csv",h1_ene_sr,h1_dirx_sr,h1_diry_sr,h1_dirz_sr,h1_posx_sr,h1_posy_sr,h1_posz_sr,h1_ene_dirx_sr,h1_ene_diry_sr,h1_ene_dirz_sr);

	h1_ene_sr->Write();
	h1_dirx_sr->Write();
	h1_diry_sr->Write();
	h1_dirz_sr->Write();
	h1_posx_sr->Write();
	h1_posy_sr->Write();
	h1_posz_sr->Write();
	h1_ene_dirx_sr->Write();
	h1_ene_diry_sr->Write();
	h1_ene_dirz_sr->Write();
	file->Close();

	cout<<"Output Synrad+ file name = "<<file->GetName()<<endl;

	return;
}

void readSynRadData(TString inputFileName, TH1D* h1_ene, TH1D* h1_dirx, TH1D* h1_diry, TH1D* h1_dirz, TH1D* h1_posx, TH1D* h1_posy, TH1D* h1_posz, TH2D* h1_ene_dirx, TH2D* h1_ene_diry, TH2D* h1_ene_dirz)
{
	// clean data vectors
	Pos_X_cm.clear();
	Pos_Y_cm.clear();
	Pos_Z_cm.clear();
	Pos_u.clear();
	Pos_v.clear();
	Dir_X.clear();
	Dir_Y.clear();
	Dir_Z.clear();
	Dir_theta_rad.clear();
	Dir_phi_rad.clear(); 
	LowFluxRatio.clear();
	Energy_eV.clear();
	Flux_phs.clear();
	Power_W.clear();

	// read a CSV file
	readCSVfile(inputFileName);

	for(Int_t i = 0; i < Energy_eV.size(); i++)
	{
		if(Energy_eV.at(i) > 30.0)
		{
			h1_ene->Fill(Energy_eV.at(i),Flux_phs.at(i));
			h1_posx->Fill(Pos_X_cm.at(i),Flux_phs.at(i));
			h1_posy->Fill(Pos_Y_cm.at(i),Flux_phs.at(i));
			h1_posz->Fill(Pos_Z_cm.at(i),Flux_phs.at(i));
			h1_dirx->Fill(Dir_X.at(i),Flux_phs.at(i));
			h1_diry->Fill(Dir_Y.at(i),Flux_phs.at(i));
			h1_dirz->Fill(Dir_Z.at(i),Flux_phs.at(i));
			h1_ene_dirx->Fill(Dir_X.at(i),Energy_eV.at(i),Flux_phs.at(i));
			h1_ene_diry->Fill(Dir_Y.at(i),Energy_eV.at(i),Flux_phs.at(i));
			h1_ene_dirz->Fill(Dir_Z.at(i),Energy_eV.at(i),Flux_phs.at(i));
		}
	}

	return;
}

void readCSVfile(TString fName)
{
	cout<<"Input file name: "<<fName<<endl;

	// Create an input filestream
    	ifstream myFile(fName.Data());

    	// Helper vars
    	string line, colname;
    	Double_t val;

    	// Read data, line by line
	getline(myFile, line); // skepp the first title line

    	while(getline(myFile, line))
    	{
        	// Create a stringstream of the current line
        	stringstream ss(line);
        
        	// Keep track of the current column index
        	Int_t colIdx = 0;
        
        	// Extract each value
        	while(ss >> val)
		{
            		// Add the current integer to the 'colIdx' column's values vector
			switch(colIdx)
			{
				case 0:
					Pos_X_cm.push_back(val);
					break;
				case 1:
					Pos_Y_cm.push_back(val);
					break;
				case 2:
					Pos_Z_cm.push_back(val);
					break;
				case 3:
					Pos_u.push_back(val);
					break;
				case 4:
					Pos_v.push_back(val);
					break;
				case 5:
					Dir_X.push_back(val);
					break;
				case 6:
					Dir_Y.push_back(val);
					break;
				case 7:
					Dir_Z.push_back(val);
					break;
				case 8:
					Dir_theta_rad.push_back(val);
					break;
				case 9:
					Dir_phi_rad.push_back(val);
					break;
				case 10:
					LowFluxRatio.push_back(val);
					break;
				case 11:
					Energy_eV.push_back(val);
					break;
				case 12:
					Flux_phs.push_back(val);
					break;
				case 13:
					Power_W.push_back(val);
					break;
			}
            
            		// If the next token is a comma, ignore it and move on
            		if(ss.peek() == ',') ss.ignore();
            
            		// Increment the column index
            		colIdx++;
        	}
    	}

    	// Close file
    	myFile.close();

	return;
}
